package com.sorting_pagination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSortingPaginationApplicationTests {

	@Test
	void contextLoads() {
	}

}
